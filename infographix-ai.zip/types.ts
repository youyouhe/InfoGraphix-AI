export interface ChartDataPoint {
  name: string;
  value: number;
  [key: string]: string | number;
}

export enum SectionType {
  TEXT = 'text',
  STAT_HIGHLIGHT = 'stat_highlight', // Big number card
  BAR_CHART = 'bar_chart',
  PIE_CHART = 'pie_chart',
  PROCESS_FLOW = 'process_flow', // Step by step flow
  COMPARISON = 'comparison', // Side by side
}

export interface InfographicSection {
  type: SectionType;
  title?: string;
  content?: string; // For text
  data?: ChartDataPoint[]; // For charts
  statValue?: string; // For highlights
  statLabel?: string; // For highlights
  statTrend?: 'up' | 'down' | 'neutral'; // For highlights
  steps?: { step: number; title: string; description: string }[]; // For process flow
  comparisonItems?: { left: string; right: string; label: string }[]; // For comparison
}

export interface InfographicReport {
  title: string;
  summary: string;
  sections: InfographicSection[];
  sources?: { title: string; uri: string }[];
}

export interface HistoryItem {
  id: string;
  query: string;
  timestamp: number;
  report?: InfographicReport;
}