import React, { useState, useRef, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import { generateInfographic } from './services/geminiService';
import { HistoryItem, InfographicReport, SectionType } from './types';
import { TextSection, StatHighlight, ChartSection, ProcessFlow, ComparisonSection } from './components/Visuals';
import { Share2, Download, ExternalLink, Sparkles, ArrowDown, Loader2, Moon, Sun, Bug, X } from 'lucide-react';

export default function App() {
  const [history, setHistory] = useState<HistoryItem[]>([]);
  const [currentReport, setCurrentReport] = useState<InfographicReport | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [isDarkMode, setIsDarkMode] = useState(true);
  const [showDebug, setShowDebug] = useState(false);

  const contentRef = useRef<HTMLDivElement>(null);
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const prevSectionCount = useRef(0);

  useEffect(() => {
    if (isDarkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [isDarkMode]);

  // Smooth scroll to bottom when new sections are added during streaming
  useEffect(() => {
    if (!currentReport) {
      prevSectionCount.current = 0;
      return;
    }

    const currentCount = currentReport.sections?.length || 0;

    if (loading && currentCount > prevSectionCount.current) {
      // Small timeout to allow render
      setTimeout(() => {
        if (scrollContainerRef.current) {
          scrollContainerRef.current.scrollTo({
            top: scrollContainerRef.current.scrollHeight,
            behavior: 'smooth'
          });
        }
      }, 100);
    }

    prevSectionCount.current = currentCount;
  }, [currentReport?.sections?.length, loading]);

  const handleGenerate = async (topic: string) => {
    setLoading(true);
    setError(null);
    setCurrentReport(null);

    try {
      const report = await generateInfographic(topic, (partialReport) => {
        // Stream update: only update if we have meaningful content
        if (partialReport.title || (partialReport.sections && partialReport.sections.length > 0)) {
          setCurrentReport(prev => ({
            ...partialReport,
            // Keep sources if we already had them (though usually sources come last)
            sources: prev?.sources || partialReport.sources
          }));
        }
      });

      // Final success state
      const newHistoryItem: HistoryItem = {
        id: Date.now().toString(),
        query: topic,
        timestamp: Date.now(),
        report: report
      };
      
      setHistory(prev => [newHistoryItem, ...prev]);
      setCurrentReport(report);
    } catch (err: any) {
      setError(err.message || "Failed to generate infographic. Please check your API key.");
    } finally {
      setLoading(false);
    }
  };

  const handleSelectHistory = (id: string) => {
    const item = history.find(h => h.id === id);
    if (item && item.report) {
      setCurrentReport(item.report);
      setError(null);
    }
  };

  const handleClearHistory = () => {
    setHistory([]);
    setCurrentReport(null);
  };

  const handleNewChat = () => {
    setCurrentReport(null);
    setError(null);
  };

  // Render a specific section based on its type
  const renderSection = (section: any, index: number) => {
    const props = { ...section, isDark: isDarkMode, isLoading: loading };
    switch (section.type) {
      case SectionType.TEXT:
        return <TextSection key={index} {...props} />;
      case SectionType.STAT_HIGHLIGHT:
        return <StatHighlight key={index} section={section} isDark={isDarkMode} isLoading={loading} />;
      case SectionType.BAR_CHART:
      case SectionType.PIE_CHART:
        return <ChartSection key={index} section={section} isDark={isDarkMode} isLoading={loading} />;
      case SectionType.PROCESS_FLOW:
        return <ProcessFlow key={index} section={section} isDark={isDarkMode} isLoading={loading} />;
      case SectionType.COMPARISON:
        return <ComparisonSection key={index} section={section} isDark={isDarkMode} isLoading={loading} />;
      default:
        return null;
    }
  };

  return (
    <div className="flex flex-col md:flex-row h-screen w-full bg-gray-50 dark:bg-[#161618] overflow-hidden text-gray-900 dark:text-white transition-colors duration-300">
      {/* Left Sidebar */}
      <Sidebar 
        history={history}
        onSelectHistory={handleSelectHistory}
        onClearHistory={handleClearHistory}
        onNewChat={handleNewChat}
        onGenerate={handleGenerate}
        isLoading={loading}
      />

      {/* Main Content Area */}
      <div className="flex-1 flex flex-col h-full relative overflow-hidden">
        {/* Top Bar */}
        <div className="h-16 bg-white dark:bg-[#1a1b1e] border-b border-gray-200 dark:border-zinc-800 flex items-center justify-between px-6 flex-shrink-0 transition-colors duration-300">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 rounded-full bg-red-500" />
            <div className="w-3 h-3 rounded-full bg-yellow-500" />
            <div className="w-3 h-3 rounded-full bg-green-500" />
          </div>
          <div className="bg-gray-100 dark:bg-black/30 px-4 py-1.5 rounded-full text-xs font-mono text-gray-600 dark:text-zinc-500 flex items-center gap-2">
             <span className={`w-2 h-2 rounded-full bg-indigo-500 ${loading ? 'animate-ping' : ''}`}></span>
             {loading ? 'Streaming...' : 'Preview Mode'}
          </div>
          <div className="flex gap-2 items-center">
             <button 
              onClick={() => setShowDebug(!showDebug)}
              className={`p-2 rounded-lg transition-colors ${showDebug ? 'bg-indigo-100 text-indigo-600 dark:bg-indigo-500/20 dark:text-indigo-400' : 'hover:bg-gray-100 dark:hover:bg-zinc-800 text-gray-500 dark:text-zinc-400'}`}
              title="Toggle Debug View"
            >
              <Bug size={18} />
            </button>
            <div className="w-px h-4 bg-gray-300 dark:bg-zinc-700 mx-1"></div>
             <button 
              onClick={() => setIsDarkMode(!isDarkMode)}
              className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg text-gray-500 dark:text-zinc-400 transition-colors" 
              title="Toggle Theme"
            >
              {isDarkMode ? <Sun size={18} /> : <Moon size={18} />}
            </button>
            <div className="w-px h-4 bg-gray-300 dark:bg-zinc-700 mx-1"></div>
            <button className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg text-gray-500 dark:text-zinc-400 transition-colors" title="Copy Text">
              <Share2 size={18} />
            </button>
             <button className="p-2 hover:bg-gray-100 dark:hover:bg-zinc-800 rounded-lg text-gray-500 dark:text-zinc-400 transition-colors" title="Export Image (Not Implemented)">
              <Download size={18} />
            </button>
          </div>
        </div>

        {/* Scrollable Content */}
        <div 
          ref={scrollContainerRef}
          className="flex-1 overflow-y-auto p-4 md:p-8 relative bg-dot-pattern scroll-smooth"
        >
          {/* Initial Loading State (Before any content) */}
          {loading && !currentReport && (
            <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-50 dark:bg-[#161618] z-50">
              <div className="relative">
                <div className="w-16 h-16 border-4 border-indigo-500/30 border-t-indigo-500 rounded-full animate-spin"></div>
                <div className="absolute inset-0 flex items-center justify-center">
                  <Sparkles size={20} className="text-indigo-500 dark:text-indigo-400 animate-pulse" />
                </div>
              </div>
              <h2 className="mt-8 text-xl font-light text-gray-900 dark:text-white">Synthesizing Research...</h2>
              <p className="text-gray-500 dark:text-zinc-500 mt-2 text-sm">Gathering data from valid sources</p>
            </div>
          )}

          {/* Empty State */}
          {!currentReport && !loading && !error && (
            <div className="h-full flex flex-col items-center justify-center opacity-30 select-none pointer-events-none">
               <div className="w-64 h-64 rounded-full bg-gradient-to-t from-indigo-500/20 to-transparent blur-3xl absolute" />
               <h1 className="text-4xl font-bold text-gray-900 dark:text-white mb-4 z-10">InfoGraphix AI</h1>
               <p className="text-gray-500 dark:text-zinc-400 max-w-md text-center z-10">
                 Enter a complex topic on the left to generate a beautiful, data-driven infographic report powered by Gemini.
               </p>
            </div>
          )}

          {/* Error State */}
          {error && (
             <div className="flex flex-col items-center justify-center h-full text-red-500 dark:text-red-400">
               <div className="bg-red-50 dark:bg-red-500/10 p-6 rounded-xl border border-red-200 dark:border-red-500/20 max-w-lg text-center">
                  <h3 className="text-lg font-bold mb-2">Generation Failed</h3>
                  <p>{error}</p>
               </div>
             </div>
          )}

          {/* Content Render */}
          {currentReport && (
            <div ref={contentRef} className="max-w-4xl mx-auto space-y-8 pb-20 animate-fade-in">
              {/* Report Header */}
              <div className="text-center mb-16 relative">
                 <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[120%] h-[120%] bg-indigo-500/5 dark:bg-indigo-500/10 blur-3xl rounded-full pointer-events-none" />
                 <h1 className="text-4xl md:text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-gray-900 via-indigo-600 to-indigo-800 dark:from-white dark:via-indigo-200 dark:to-indigo-400 mb-6 relative z-10">
                   {currentReport.title || <span className="animate-pulse bg-gray-200 dark:bg-zinc-800 rounded h-16 w-3/4 inline-block"></span>}
                 </h1>
                 <div className="max-w-2xl mx-auto bg-white/50 dark:bg-zinc-900/80 backdrop-blur border border-gray-200 dark:border-zinc-700 p-6 rounded-2xl relative z-10 shadow-xl dark:shadow-2xl">
                    <p className="text-lg text-gray-700 dark:text-zinc-300 leading-relaxed font-light">
                      {currentReport.summary || <span className="animate-pulse bg-gray-200 dark:bg-zinc-800 rounded h-20 w-full inline-block"></span>}
                    </p>
                 </div>
              </div>

              {/* Sections */}
              <div className="flex flex-col gap-2">
                {currentReport.sections && currentReport.sections.map((section, idx) => (
                  <React.Fragment key={idx}>
                    <div className="relative transition-all duration-500 hover:translate-y-[-2px]">
                      {/* Subtle background glow for visual variation on even items */}
                      {idx % 2 === 1 && (
                        <div className="absolute -inset-4 bg-gradient-to-b from-transparent via-gray-200/50 dark:via-zinc-800/20 to-transparent rounded-[2rem] -z-10 blur-xl opacity-50" />
                      )}
                      
                      {renderSection(section, idx)}
                    </div>

                    {/* Divider / Flow Connector */}
                    {idx < currentReport.sections.length - 1 && (
                      <div className="flex flex-col items-center justify-center py-4 opacity-30 gap-1">
                         <div className="h-6 w-px bg-gradient-to-b from-gray-300 dark:from-zinc-700 to-transparent" />
                         <ArrowDown size={14} className="text-gray-400 dark:text-zinc-500" />
                      </div>
                    )}
                  </React.Fragment>
                ))}
                
                {/* Streaming Indicator at bottom of content */}
                {loading && (
                   <div className="flex justify-center py-8">
                      <Loader2 className="animate-spin text-indigo-500" size={24} />
                   </div>
                )}
              </div>

              {/* Footer Sources */}
              {currentReport.sources && currentReport.sources.length > 0 && !loading && (
                <div className="mt-16 pt-8 border-t border-gray-200 dark:border-zinc-800 animate-in fade-in slide-in-from-bottom-4 duration-700">
                  <h4 className="text-xs uppercase tracking-widest text-gray-500 dark:text-zinc-500 mb-4">Sources & References</h4>
                  <div className="flex flex-wrap gap-3">
                    {currentReport.sources.map((source, i) => (
                      <a 
                        key={i} 
                        href={source.uri} 
                        target="_blank" 
                        rel="noreferrer"
                        className="flex items-center gap-2 px-3 py-2 bg-white dark:bg-zinc-900 rounded-lg border border-gray-200 dark:border-zinc-800 hover:border-indigo-500/50 hover:bg-gray-50 dark:hover:bg-zinc-800 transition-colors text-xs text-gray-500 dark:text-zinc-400 hover:text-indigo-600 dark:hover:text-indigo-300 shadow-sm dark:shadow-none"
                      >
                        <ExternalLink size={12} />
                        <span className="truncate max-w-[200px]">{source.title}</span>
                      </a>
                    ))}
                  </div>
                </div>
              )}
            </div>
          )}
        </div>

        {/* Debug Panel - Absolute positioned over content */}
        {showDebug && (
           <div className="absolute top-16 right-0 bottom-0 w-full md:w-[450px] bg-white/95 dark:bg-[#1a1b1e]/95 backdrop-blur-md border-l border-gray-200 dark:border-zinc-800 shadow-2xl z-50 flex flex-col animate-in slide-in-from-right duration-200">
             <div className="p-3 border-b border-gray-200 dark:border-zinc-800 flex justify-between items-center bg-gray-50/50 dark:bg-zinc-900/50">
               <div className="flex items-center gap-2">
                 <Bug size={14} className="text-indigo-500" />
                 <span className="text-xs font-bold uppercase tracking-wider text-gray-900 dark:text-white">Live LLM Output</span>
               </div>
               <button 
                 onClick={() => setShowDebug(false)}
                 className="p-1 hover:bg-gray-200 dark:hover:bg-zinc-800 rounded text-gray-500 dark:text-zinc-400 transition-colors"
               >
                 <X size={16} />
               </button>
             </div>
             <div className="flex-1 overflow-auto p-4 bg-gray-50 dark:bg-[#0c0c0e]">
               {currentReport ? (
                 <pre className="text-[10px] md:text-xs font-mono text-gray-600 dark:text-green-400 whitespace-pre-wrap break-all leading-relaxed">
                   {JSON.stringify(currentReport, null, 2)}
                 </pre>
               ) : (
                 <div className="h-full flex flex-col items-center justify-center text-gray-400 dark:text-zinc-600 italic gap-2">
                   <Bug size={32} className="opacity-20" />
                   <p>No active report data</p>
                 </div>
               )}
             </div>
           </div>
        )}

      </div>
    </div>
  );
}